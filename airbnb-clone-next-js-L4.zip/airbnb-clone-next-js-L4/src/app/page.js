"use client"
import PropertyListings from "@/app/components/propertyListings";

export default function Home() {

    return (
        <main>
            <PropertyListings/>
        </main>
    );
}
